import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbartop from './components/Navbartop';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
function App() {
  return (
    <div>
      <Router>
          <Navbartop/>
          <Routes>
                {/* <Route path ="/" element ={<Home/>} /> */}
                
          </Routes>
          {/* <Footer/> */}
      </Router>
    </div>
  );
}

export default App;
