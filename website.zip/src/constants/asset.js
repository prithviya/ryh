export default
{
    BANNER_SECTION: require("../images/banner.jpg"),
    MENU_ICON: require("../images/menu.svg"),
};